#!/usr/bin/env python

import rospy
from geometry_msgs.msg import PoseStamped
from geometry_msgs.msg import TwistStamped
from mavros_msgs.msg import State
from mavros_msgs.srv import CommandBool, CommandBoolRequest, SetMode, SetModeRequest, CommandTOL
import math
import numpy as np
from scipy import interpolate
from geometry_msgs.msg import PoseStamped
import time


current_state = State()
current_pose = PoseStamped()

def state_cb(msg):
    global current_state
    current_state = msg

def pose_cb(msg):
    global current_pose
    current_pose = msg

def check_distance(pose1, pose2):
    """Calculate Euclidean distance between two poses."""
    dx = pose2.pose.position.x - pose1.pose.position.x
    dy = pose2.pose.position.y - pose1.pose.position.y
    dz = pose2.pose.position.z - pose1.pose.position.z
    return math.sqrt(dx**2 + dy**2 + dz**2), dx,dy,dz

def PID_Controller(dx,dy,dz,d2x,d2y,d2z,ex,ey,ez):
    P_gain = 0.5
    I_Gain = 0.008
    D_Gain = 5
    

    print('Args:',dx,dy,dz,d2x,d2y,d2z,ex,ey,ez)

    #Vel_X
    P_x = dx*P_gain
    D_x = d2x * D_Gain
    I_x = ex* I_Gain
    vel_x = P_x + I_x +D_x
    
    #Vel_X
    P_y = dy*P_gain
    D_y = d2y * D_Gain
    I_y = ey* I_Gain
    vel_y = P_y + I_y +D_y

    #Vel_X
    P_z = dz*P_gain
    D_z = d2z * D_Gain
    I_z = ez* I_Gain
    vel_z = P_z + I_z +D_z


    vel_msg = TwistStamped()
    vel_msg.header.stamp = rospy.Time.now()
    vel_msg.twist.linear.x = vel_x
    vel_msg.twist.linear.y = vel_y
    vel_msg.twist.linear.z = vel_z
    #vel_pub.publish(vel_msg)
    
    return(vel_msg)

def navigate_to_waypoints(waypoints, local_pos_pub, vel_pub):
    rate = rospy.Rate(50)  # 20 Hz
    last_request = rospy.Time.now()
    d2x,d2y,d2z = 0,0,0
    dx0,dy0,dz0 = 0,0,0
    ex,ey,ez = 0,0,0
    for pose in waypoints:
        rospy.loginfo("Moving to waypoint: %s", pose)
        #local_pos_pub.publish(pose)
        print('CPose',current_pose)
        dist,dx,dy,dz = check_distance(current_pose, pose)
        print(dist)
        d2x,d2y,d2z = dx-dx0,dy-dy0,dz-dz0 
        dx0,dy0,dz0 = dx,dy,dz 
        ex,ey,ez = ex+dx,ey+dy,ez+dz
        vel_msg = PID_Controller(dx,dy,dz,d2x,d2y,d2z,ex,ey,ez )
        vel_pub.publish(vel_msg)
        while dist > 0.3:
            #print(pose)
            print('CPose',current_pose)
            dist,dx,dy,dz = check_distance(current_pose, pose)
            print(dist)
            d2x,d2y,d2z = dx-dx0,dy-dy0,dz-dz0 
            dx0,dy0,dz0 = dx,dy,dz
            ex,ey,ez = ex+dx,ey+dy,ez+dz
            vel_msg = PID_Controller(dx,dy,dz,d2x,d2y,d2z,ex,ey,ez )
            # Publish the current setpoint
            vel_pub.publish(vel_msg)
            #local_pos_pub.publish(pose)

            # Check if the drone has reached the waypoint
            #if check_distance(current_pose, pose) < 0.1 and (rospy.Time.now() - last_req) > rospy.Duration(5.0):  # Adjust the threshold distance as needed
            #    rospy.loginfo("Reached waypoint: %s", pose)
            #    last_req = rospy.Time.now()
            #    break

            rate.sleep()

def generate_bspline_interpolation(control_points, degree=3, num_samples=5):
    
    # Convert control points to numpy array
    control_points = np.array(control_points)

    # Extract x, y, z coordinates from control points
    x = control_points[:, 0]
    y = control_points[:, 1]
    z = control_points[:, 2]

    # uncomment both lines for a closed curve
    x = np.append(x, [x[0]])
    y = np.append(y, [y[0]])
    z = np.append(z, [z[0]])

    l = len(x)

    # Create parameter values for the knots
    t = np.linspace(0, 1, l - 2, endpoint=True)
    t = np.append([0, 0, 0], t)
    t = np.append(t, [1, 1, 1])

    # Perform B-spline interpolation
    tck, u = interpolate.splprep([x, y, z], k=degree)
    out = interpolate.splev(np.linspace(0, 1, num_samples), tck)
    print('OUT:',out[0])
    # Convert curve points to PoseStamped messages
    #time.sleep(100)
    altitude = 1.5
    pose_msgs = []
    for i in range(len(out[0])):
        pose_msg = PoseStamped()
        pose_msg.pose.position.x = (out[0][i])
        pose_msg.pose.position.y = (out[1][i])
        pose_msg.pose.position.z = altitude#(out[2][i])
        pose_msgs.append(pose_msg)
        #print(out)

    return pose_msgs, out[0], out[1], out[2]

def land():
    print('Landing Process ongoing')
    rospy.wait_for_service('/mavros/cmd/land')
    try:
        land_service = rospy.ServiceProxy('/mavros/cmd/land', CommandTOL)
        response = land_service(min_pitch=0, yaw=0, latitude=0, longitude=0, altitude=0)
        return response.success
    except rospy.ServiceException as e:
        print("Service call failed: %s" % e)

def main():
    rospy.init_node("offb_node_py")

    # Subscribers
    state_sub = rospy.Subscriber("mavros/state", State, callback=state_cb)
    pose_sub = rospy.Subscriber("mavros/local_position/pose", PoseStamped, callback=pose_cb)

    # Publisher
    local_pos_pub = rospy.Publisher("mavros/setpoint_position/local", PoseStamped, queue_size=10)
    vel_pub = rospy.Publisher('/mavros/setpoint_velocity/cmd_vel', TwistStamped, queue_size=10)
    

    # Service clients
    rospy.wait_for_service("/mavros/cmd/arming")
    arming_client = rospy.ServiceProxy("mavros/cmd/arming", CommandBool)

    rospy.wait_for_service("/mavros/set_mode")
    set_mode_client = rospy.ServiceProxy("mavros/set_mode", SetMode)

    # Wait for the connection to the flight controller
    rospy.loginfo("Waiting for FCU connection...")
    while not rospy.is_shutdown() and not current_state.connected:
        rospy.sleep(0.1)

    control_points = [(1, 0, 1.5), (2, 0, 1), (1.5, 1, 1.5), (2, 2, 1.5),
                  (2, 1, 1), (2.5, 2.2, 1.5), (1, 2, 1.5), (0, 0, 1), (0, 0, 0)]
    curve_poses, curve_x, curve_y, curve_z = generate_bspline_interpolation(control_points)

    # Print curve poses
    #for i, pose in enumerate(curve_poses):
    #    print("Pose {}: x={}, y={}, z={}".format(i, pose.pose.position.x, pose.pose.position.y, pose.pose.position.z))

    waypoints = curve_poses
    
    waypoints1 =[
        PoseStamped(),  # Define your waypoints here
       # Define your waypoints here
        
        # Add more waypoints as needed
    ]

    waypoints1[0].pose.position.x = 0.0  # Define x position
    waypoints1[0].pose.position.y = 0.0  # Define y position
    waypoints1[0].pose.position.z = 2.0  # Define z position
    
    

    # Set the mode to OFFBOARD and arm the vehicle
    offb_set_mode = SetModeRequest()
    offb_set_mode.custom_mode = 'OFFBOARD'
    arm_cmd = CommandBoolRequest()
    arm_cmd.value = True
    last_req = rospy.Time.now()
    rate = rospy.Rate(20)

    while (current_state.mode != "OFFBOARD" and not current_state.armed):
    
        if(current_state.mode != "OFFBOARD" and (rospy.Time.now() - last_req) > rospy.Duration(5.0)):
            if(set_mode_client.call(offb_set_mode).mode_sent == True):
                rospy.loginfo("OFFBOARD enabled")

            last_req = rospy.Time.now()
        else:
            if(not current_state.armed and (rospy.Time.now() - last_req) > rospy.Duration(5.0)):
                if(arming_client.call(arm_cmd).success == True):
                    rospy.loginfo("Vehicle armed")

                last_req = rospy.Time.now()
   
    print('Vehicle Armed and in offboard mode')   
    dist = 1
    while(not rospy.is_shutdown() and dist>0.1):  
        dist,dx,dy,dz = check_distance(current_pose, waypoints1[0])
        print(dist)
        
        if(current_state.mode != "OFFBOARD" and (rospy.Time.now() - last_req) > rospy.Duration(5.0)):
            if(set_mode_client.call(offb_set_mode).mode_sent == True):
                rospy.loginfo("OFFBOARD enabled")

            last_req = rospy.Time.now()
        else:
            if(not current_state.armed and (rospy.Time.now() - last_req) > rospy.Duration(5.0)):
                if(arming_client.call(arm_cmd).success == True):
                    rospy.loginfo("Vehicle armed")

                last_req = rospy.Time.now()
        # Publish the current setpoint
        
        local_pos_pub.publish(waypoints1[0])

        
        rate.sleep()   

    # Navigate to waypoints
    navigate_to_waypoints(waypoints, local_pos_pub, vel_pub)

    #altitude hold mode 
    print('ALT_Control Mode')
    offb_set_mode.custom_mode = 'ALTCTL'

    if(set_mode_client.call(offb_set_mode).mode_sent == True):
                rospy.loginfo("ALT HOLD enabled")

    time.sleep(10)    
    print('Landing')
    offb_set_mode.custom_mode = 'AUTO.LAND'

    if(set_mode_client.call(offb_set_mode).mode_sent == True):
                rospy.loginfo("ALT HOLD enabled")

if __name__ == "__main__":
    try:
        main()
    except rospy.ROSInterruptException:
        pass
